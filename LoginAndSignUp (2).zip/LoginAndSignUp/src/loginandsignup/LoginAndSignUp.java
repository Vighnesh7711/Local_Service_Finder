
package loginandsignup;

public class LoginAndSignUp {


    public static void main(String[] args) {

        UserInterfaceee UserInterfaceeeFrame = new UserInterfaceee();
        UserInterfaceeeFrame.setVisible(true);
        UserInterfaceeeFrame.pack();
        UserInterfaceeeFrame.setLocationRelativeTo(null);
    }
    
}
